lib_stats = {
    'Сила': 'strength',
    'Здоровье': 'health',
    'Скорость': 'speed',
    'Ловкость': 'dexterity',
    'Меткость': 'accuracy',
    'Дух': 'soul',
    'Интеллект': 'intelligence',
    'Подчинение': 'submission',
}