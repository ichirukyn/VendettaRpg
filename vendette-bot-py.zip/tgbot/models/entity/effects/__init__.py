import operator

condition_operator = {
    '>': operator.gt,
    '<': operator.lt,
    '>=': operator.ge,
    '<=': operator.le,
    '==': operator.eq,
    '!=': operator.ne
}

magic_filter = ['intelligence', 'submission', 'soul']
