from typing import TypedDict


class LevelType(TypedDict):
    lvl: int
    exp_to_lvl: int
    exp_total: int
